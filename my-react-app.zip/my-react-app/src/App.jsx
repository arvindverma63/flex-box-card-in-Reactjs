import Card from './Card.jsx'


function App(){
    return (
      <>
       <Card></Card>
      </>
    );
}
export default App