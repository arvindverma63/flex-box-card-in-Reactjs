import card from './assets/card.png'
import card2 from './assets/card2.jpg'
import card3 from './assets/card3.jpg'
function Card(){
    return (
        <div className="card-position">
        <div className="card">
            <center><img src={card2} className='img'></img></center>
            <h4>This is a Card</h4>
            <p>hello firends this is react js</p>
        </div>
        <div className="card">
            <center><img src={card3} className='img'></img></center>
            <h4>This is a Card</h4>
            <p>hello firends this is react js</p>
        </div>
        <div className="card">
            <center><img src={card} className='img'></img></center>
            <h4>This is a Card</h4>
            <p>hello firends this is react js</p>
        </div>
        </div>
    );
}
export default Card